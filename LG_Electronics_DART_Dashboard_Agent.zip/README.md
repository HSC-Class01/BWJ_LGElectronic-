# LG전자 DART Financial Dashboard

> OpenDART를 이용해 LG전자(066570)의 정기보고서 재무데이터를 자동 수집하고, 재무비율을 계산하여 GitHub Pages 대시보드로 제공하는 프로젝트입니다.

## 🔗 대시보드 바로가기

[![대시보드 바로가기](https://img.shields.io/badge/%F0%9F%94%97-%EB%8C%80%EC%8B%9C%EB%B3%B4%EB%93%9C%20%EB%B0%94%EB%A1%9C%EA%B0%80%EA%B8%B0-111827?style=for-the-badge)](./dashboard/)

> GitHub Pages를 활성화하면 위 링크를 Pages URL로 변경하세요. 저장소의 **About → Website**에도 동일한 URL을 넣습니다.

## 주요 기능

- OpenDART API 기반 LG전자 재무제표 수집
- Annual / Half-year / Quarterly 데이터 분리
- 주요 재무수치 자동 추출
- 수익성·유동성·재무안정성·활동성·성장성 비율 계산
- 매월 1일 GitHub Actions 자동 업데이트
- GitHub Pages 정적 대시보드
- 국내 Peer Firms 표
- API Key를 GitHub Secrets로 관리

## 첨부된 실무 가이드 기준

분석 항목은 제공된 **「재무제표 및 재무비율 실무 가이드」**를 기준으로 구성했습니다.

핵심 수치는 총자산, 현금및현금성자산, 매출채권, 재고자산, 유형자산, 총부채, 이자부차입금, 자본총계, 매출액, 매출총이익, 판매비와관리비, 영업이익, 세전이익, 당기순이익, 지배주주순이익, EBITDA, 영업활동현금흐름, 투자활동현금흐름, 재무활동현금흐름, CAPEX, FCF, 순차입금 등을 대상으로 합니다.

비율은 매출총이익률, 영업이익률, 순이익률, EBITDA 마진, ROA, ROE, ROIC, 유동비율, 당좌비율, 부채비율, 자기자본비율, 차입금의존도, 이자보상배율, 순차입금/EBITDA, 총자산회전율, DSO, DIO, DPO, CCC, 매출증가율, CFO/순이익, PER, PBR, EV/EBITDA 등을 확장 가능한 구조로 제공합니다.

> 주의: 가이드에서도 재무비율 정의는 기관·기업에 따라 달라질 수 있다고 설명합니다. 따라서 코드에서는 계산 정의를 `src/ratio_analysis.py`에 명시합니다.

## OpenDART API 설정

1. OpenDART에서 API 인증키를 발급합니다.
2. GitHub 저장소의  
   **Settings → Secrets and variables → Actions → New repository secret**
3. 이름을 다음과 같이 입력합니다.

```text
DART_API_KEY
```

4. 값에는 OpenDART의 40자리 인증키를 입력합니다.
5. 저장 후 Actions에서 `Update LG Electronics Dashboard`를 수동 실행하여 테스트할 수 있습니다.

OpenDART의 고유번호 API는 8자리 `corp_code`를 제공하며, 단일회사 주요 재무지표 API는 사업연도와 보고서 코드(1분기 11013, 반기 11012, 3분기 11014, 사업보고서 11011)를 사용합니다.

## 로컬 실행

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

환경변수:

```bash
export DART_API_KEY="발급받은_40자리_키"
```

실행:

```bash
python scripts/update_data.py
```

생성 파일:

```text
data/annual.csv
data/half_year.csv
data/quarterly.csv
data/ratios.csv
```

## GitHub Pages 설정

Repository → Settings → Pages → Build and deployment에서 GitHub Actions를 선택합니다.

워크플로우가 정상 실행되면 Pages가 자동 배포됩니다.

## 자동 업데이트

`.github/workflows/update-dashboard.yml`에서 매월 1일 실행되도록 설정되어 있습니다. `workflow_dispatch`도 포함되어 있어 수동 테스트가 가능합니다.

## Peer Firms

초기 비교군은 국내 전자·부품·디스플레이·배터리 산업의 비교 목적 후보로 다음 기업을 제공합니다.

| 기업 | 종목코드 | 비교 관점 |
|---|---:|---|
| 삼성전자 | 005930 | 종합 전자·반도체·가전 |
| LG디스플레이 | 034220 | 디스플레이 패널 |
| 삼성전기 | 009150 | 전자부품 |
| 삼성SDI | 006400 | 배터리·전자소재 |
| SK하이닉스 | 000660 | 반도체 |

Peer Firms는 순위나 투자판단을 위한 평가표가 아니라 사업 및 재무지표 비교용 표입니다. 필요하면 `config/peers.json`에서 기업을 추가/삭제할 수 있습니다.

## 프로젝트 구조

```text
.github/workflows/update-dashboard.yml
config/company.json
config/metrics.json
config/peers.json
data/
dashboard/index.html
scripts/update_data.py
src/dart_client.py
src/financial_parser.py
src/ratio_analysis.py
requirements.txt
```


## GitHub Actions workflow 업로드 주의

ZIP에는 사용자가 요청한 대로 **숨김 경로 `.github/`를 포함하지 않았습니다.**
따라서 GitHub에 업로드한 뒤 `GITHUB_WORKFLOW_update-dashboard.yml` 파일의 내용을 복사하여
저장소의 아래 경로에 생성하세요.

```text
.github/workflows/update-dashboard.yml
```

이 경로가 GitHub Actions에서 인식되는 표준 위치입니다.
