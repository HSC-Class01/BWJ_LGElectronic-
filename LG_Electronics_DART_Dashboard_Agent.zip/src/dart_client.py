import io
import zipfile
import requests
import pandas as pd

BASE = "https://opendart.fss.or.kr/api"

class DartClient:
    def __init__(self, api_key: str):
        if not api_key or len(api_key) < 20:
            raise ValueError("DART_API_KEY가 없거나 형식이 올바르지 않습니다.")
        self.api_key = api_key

    def _get(self, endpoint, params):
        p = {"crtfc_key": self.api_key, **params}
        r = requests.get(f"{BASE}/{endpoint}", params=p, timeout=60)
        r.raise_for_status()
        return r

    def corp_code_map(self):
        r = self._get("corpCode.xml", {})
        z = zipfile.ZipFile(io.BytesIO(r.content))
        name = next(n for n in z.namelist() if n.lower().endswith(".xml"))
        import xml.etree.ElementTree as ET
        root = ET.fromstring(z.read(name))
        rows = []
        for item in root.findall(".//list"):
            rows.append({
                "corp_code": item.findtext("corp_code",""),
                "corp_name": item.findtext("corp_name",""),
                "stock_code": item.findtext("stock_code","")
            })
        return pd.DataFrame(rows)

    def find_corp_code(self, stock_code="066570"):
        df = self.corp_code_map()
        hit = df[df["stock_code"].astype(str).str.zfill(6) == str(stock_code).zfill(6)]
        if hit.empty:
            raise RuntimeError(f"종목코드 {stock_code}의 DART corp_code를 찾지 못했습니다.")
        return hit.iloc[0]["corp_code"]

    def financial_statements(self, corp_code, year, report_code, fs_div="CFS"):
        r = self._get("fnlttSinglAcntAll.json", {
            "corp_code": corp_code,
            "bsns_year": str(year),
            "reprt_code": report_code,
            "fs_div": fs_div
        })
        data = r.json()
        if data.get("status") != "000":
            raise RuntimeError(f"DART API 오류 {data.get('status')}: {data.get('message')}")
        return pd.DataFrame(data.get("list", []))

    def indexes(self, corp_code, year, report_code, idx_cl_code):
        r = self._get("fnlttSinglIndx.json", {
            "corp_code": corp_code,
            "bsns_year": str(year),
            "reprt_code": report_code,
            "idx_cl_code": idx_cl_code
        })
        data = r.json()
        if data.get("status") != "000":
            return pd.DataFrame()
        return pd.DataFrame(data.get("list", []))
