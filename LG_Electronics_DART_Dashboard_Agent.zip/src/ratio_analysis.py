import numpy as np
import pandas as pd

def safe_div(a,b):
    try:
        if pd.isna(a) or pd.isna(b) or b == 0: return np.nan
        return a/b
    except Exception:
        return np.nan

def calculate_ratios(df):
    x = df.copy()
    x["매출총이익률"] = x.apply(lambda r: safe_div(r.get("매출총이익"), r.get("매출액"))*100, axis=1)
    x["영업이익률"] = x.apply(lambda r: safe_div(r.get("영업이익"), r.get("매출액"))*100, axis=1)
    x["순이익률"] = x.apply(lambda r: safe_div(r.get("당기순이익"), r.get("매출액"))*100, axis=1)
    if "EBITDA" not in x:
        x["EBITDA"] = x.get("영업이익", np.nan)
    x["EBITDA 마진"] = x.apply(lambda r: safe_div(r.get("EBITDA"), r.get("매출액"))*100, axis=1)
    x["유동비율"] = np.nan
    x["부채비율"] = x.apply(lambda r: safe_div(r.get("총부채"), r.get("자본총계"))*100, axis=1)
    x["자기자본비율"] = x.apply(lambda r: safe_div(r.get("자본총계"), r.get("총자산"))*100, axis=1)
    x["차입금의존도"] = x.apply(lambda r: safe_div(r.get("이자부차입금"), r.get("총자산"))*100, axis=1)
    x["순차입금"] = x.get("이자부차입금", np.nan) - x.get("현금및현금성자산", np.nan)
    x["매출증가율"] = x.groupby("period")["매출액"].pct_change()*100
    x["CFO/순이익"] = x.apply(lambda r: safe_div(r.get("영업활동현금흐름"), r.get("당기순이익"))*100, axis=1)
    return x

def save_ratios(df, path):
    calculate_ratios(df).to_csv(path, index=False, encoding="utf-8-sig")
