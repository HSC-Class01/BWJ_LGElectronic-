import pandas as pd
import numpy as np

ACCOUNT_MAP = {
    "총자산": ["자산총계"],
    "현금및현금성자산": ["현금및현금성자산","현금및현금성자산성격의금융자산"],
    "매출채권": ["매출채권"],
    "재고자산": ["재고자산"],
    "유형자산": ["유형자산"],
    "총부채": ["부채총계"],
    "자본총계": ["자본총계"],
    "매출액": ["매출액","수익(매출액)"],
    "매출총이익": ["매출총이익"],
    "판매비와관리비": ["판매비와관리비"],
    "영업이익": ["영업이익","영업이익(손실)"],
    "세전이익": ["법인세비용차감전순이익","법인세비용차감전계속영업이익"],
    "당기순이익": ["당기순이익","당기순이익(손실)"],
    "지배주주순이익": ["지배기업의 소유주에게 귀속되는 당기순이익","지배기업 소유주지분 순이익"],
    "영업활동현금흐름": ["영업활동현금흐름"],
    "투자활동현금흐름": ["투자활동현금흐름"],
    "재무활동현금흐름": ["재무활동현금흐름"],
}

def _num(v):
    if v is None or str(v).strip() in ("","-"): return np.nan
    s = str(v).replace(",","").replace(" ","")
    try: return float(s)
    except: return np.nan

def extract_major_values(df):
    if df.empty: return {}
    out = {}
    for label, candidates in ACCOUNT_MAP.items():
        hit = df[df["account_nm"].astype(str).isin(candidates)]
        if hit.empty:
            # fallback: contains
            mask = pd.Series(False, index=df.index)
            for c in candidates:
                mask |= df["account_nm"].astype(str).str.contains(c, regex=False, na=False)
            hit = df[mask]
        if hit.empty:
            out[label] = np.nan
            continue
        row = hit.iloc[0]
        # Annual/quarter reports use thstrm_amount for current period.
        val = row.get("thstrm_amount")
        out[label] = _num(val)
    return out

def statement_to_record(df, year, period, fs_div="CFS"):
    vals = extract_major_values(df)
    vals.update({"year": int(year), "period": period, "fs_div": fs_div})
    return vals
