import os, sys, json
from pathlib import Path
import pandas as pd
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.dart_client import DartClient
from src.financial_parser import statement_to_record
from src.ratio_analysis import calculate_ratios

def main():
    key = os.environ.get("DART_API_KEY")
    if not key:
        raise SystemExit("DART_API_KEY 환경변수를 설정하세요.")

    cfg = json.loads((ROOT/"config/company.json").read_text(encoding="utf-8"))
    client = DartClient(key)

    corp_code = cfg.get("corp_code") or client.find_corp_code(cfg["stock_code"])
    cfg["corp_code"] = corp_code
    (ROOT/"config/company.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")

    current_year = datetime.now().year
    years = range(current_year-5, current_year+1)
    reports = [("quarterly", "11013"), ("half_year", "11012"), ("quarterly", "11014"), ("annual", "11011")]

    rows = []
    for year in years:
        for period, code in reports:
            try:
                df = client.financial_statements(corp_code, year, code, cfg.get("fs_div","CFS"))
                if df.empty: continue
                rec = statement_to_record(df, year, period, cfg.get("fs_div","CFS"))
                rec["report_code"] = code
                rows.append(rec)
            except Exception as e:
                print(f"[WARN] {year} {period}: {e}")

    if not rows:
        raise SystemExit("DART에서 재무데이터를 가져오지 못했습니다.")

    out = pd.DataFrame(rows).sort_values(["year","period"])
    # 중복 보고서가 생기면 최신 행 유지
    out = out.drop_duplicates(["year","period"], keep="last")
    out = calculate_ratios(out)

    (ROOT/"data").mkdir(exist_ok=True)
    out[out["period"]=="annual"].to_csv(ROOT/"data/annual.csv", index=False, encoding="utf-8-sig")
    out[out["period"]=="half_year"].to_csv(ROOT/"data/half_year.csv", index=False, encoding="utf-8-sig")
    out[out["period"]=="quarterly"].to_csv(ROOT/"data/quarterly.csv", index=False, encoding="utf-8-sig")
    out.to_csv(ROOT/"data/ratios.csv", index=False, encoding="utf-8-sig")

    print(f"Updated {len(out)} records for {cfg['corp_name']} ({cfg['stock_code']}).")

if __name__ == "__main__":
    main()
